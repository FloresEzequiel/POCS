package com.infosys.irs.InfyGoBoot_SpringDataJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyGoBootSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
