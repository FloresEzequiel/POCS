package com.infosys.irs.InfyGoBoot_SpringDataJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfyGoBootSpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfyGoBootSpringDataJpaApplication.class, args);
	}

}
