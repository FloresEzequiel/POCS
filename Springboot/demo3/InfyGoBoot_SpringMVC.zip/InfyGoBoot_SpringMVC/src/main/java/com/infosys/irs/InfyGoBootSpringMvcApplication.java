package com.infosys.irs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfyGoBootSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfyGoBootSpringMvcApplication.class, args);
	}

}
